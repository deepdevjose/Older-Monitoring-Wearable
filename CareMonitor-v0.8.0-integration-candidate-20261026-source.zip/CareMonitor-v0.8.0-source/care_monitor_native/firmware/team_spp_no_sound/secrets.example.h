#pragma once
// Copy to secrets.h locally; enter your network values there.
#define WIFI_SSID "YOUR_WIFI_NAME"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
